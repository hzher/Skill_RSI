"""Apply router config to the pinned native Codex adapter, then call official CLI.

No benchmark action is performed by importing this module. Docker execution has
not yet been validated; this extension must pass smoke before formal collection.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sys


def main() -> None:
    control = Path(sys.argv[1]).resolve()
    plan = json.loads(control.read_text(encoding="utf-8-sig"))
    source = Path(plan["linux_source"])
    archive = Path(plan["linux_archive"])
    native = Path(plan["linux_runtime"])
    if native.exists():
        raise RuntimeError("Runtime directory already exists; never overwrite attempts")
    native.mkdir(parents=True)
    native.joinpath("data").symlink_to(source / "data", target_is_directory=True)
    sys.path.insert(0, str(source))
    if os.environ.get("OPENAI_BASE_URL") != plan["api_base_url"]:
        raise RuntimeError("Router URL missing or inconsistent")
    if not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError("API key not injected")

    from src.registry import register_system
    from src.systems.codex.system import CodexSystem

    class RouterConfiguredCodex(CodexSystem):
        # Identical inherited constructor/signature, interaction and grading;
        # only provider configuration and explicitly selected baseline policy.
        supports_baseline = plan["include_baseline"]
        # The pinned upstream can create a spawn pool for a paired baseline
        # even with max_workers=1. Keep this locally configured class inline.
        parallel_safe = False

        def _start_container(self) -> None:
            super()._start_container()
            provider_config = (
                'model_provider = "rsi_router"\n'
                '[model_providers.rsi_router]\n'
                'name = "RSI AffordableRouter"\n'
                f'base_url = {json.dumps(plan["api_base_url"])}\n'
                'env_key = "OPENAI_API_KEY"\n'
                'wire_api = "responses"\n'
                'requires_openai_auth = false\n'
                'supports_websockets = false\n'
                'request_max_retries = 1\n'
            )
            encoded = base64.b64encode(provider_config.encode()).decode("ascii")
            result = self._docker_exec(
                "umask 077; printf '%s' " + encoded
                + " | base64 -d > /workspace/.codex/config.toml",
                timeout=15,
            )
            if result.returncode:
                raise RuntimeError("Could not install router config inside Codex container")

    register_system("codex")(RouterConfiguredCodex)
    config = plan["effective_config"]
    if plan["purpose"] == "smoke":
        # Preserve original rows byte-for-byte, containing grader-only data.
        # This file stays on the host, outside every executor mount.
        selected = set(plan["instance_ids"])
        dataset = archive / "control" / "grader-dataset.jsonl"
        matched = []
        for line in (source / "data/codebase_adaptation/final-dataset.jsonl").read_bytes().splitlines(keepends=True):
            if line.strip() and json.loads(line)["instance_id"] in selected:
                matched.append(line)
        if len(matched) != len(selected):
            raise RuntimeError("Public instance selection does not match pinned dataset")
        dataset.write_bytes(b"".join(matched))
        config["task"]["params"]["dataset_path"] = str(dataset)
    config_path = archive / "control" / "effective-clbench.json"
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    os.chdir(native)
    sys.argv = [
        "clbench", "run", "--config", str(config_path),
        "--runs", str(config["runs"]), "--max-workers", "1",
        "--run-mode", config["run_mode"],
        "--output", str(native / "summary.json"),
        "--run-group-id", plan["run_id"],
        "--no-live-dashboard", "--no-live-server",
    ]
    metadata = {
        "extension": "router config injection into upstream native Codex adapter",
        "upstream_sha": plan["benchmark_sha"],
        "include_baseline": plan["include_baseline"],
        "cli_argv": sys.argv,
        "bridge_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "runtime": str(native),
    }
    (archive / "control" / "adapter.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    signal.signal(signal.SIGINT, signal.default_int_handler)
    try:
        from src.cli import main as clbench_main
        clbench_main()
    finally:
        # Copy only native outputs. Do not copy the data symlink, venv, global
        # home, auth.json, or the Codex executor workspace containing credentials.
        target = archive / "native"
        target.mkdir(exist_ok=True)
        for item in native.iterdir():
            if item.name == "data" or item.is_symlink():
                continue
            dest = target / item.name
            if item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(item, dest)


if __name__ == "__main__":
    main()
