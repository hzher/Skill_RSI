"""Apply router config to the pinned native Codex adapter, then call official CLI.

No benchmark action is performed by importing this module. The recorded single
instance smoke validates native execution; formal test-visibility alignment is
still pending before collection.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import subprocess


def install_smoke_schedule(plan: dict) -> dict | None:
    """Expose a one-instance derivative without modifying the official catalog."""
    if plan["purpose"] != "smoke":
        return None
    from src.tasks import schedules
    original_catalog = schedules.list_task_schedules
    parent = schedules.get_task_schedule("codebase_adaptation", "default")
    selected = plan["instance_ids"]
    if len(selected) != 1:
        raise RuntimeError("Smoke schedule must contain exactly one instance")
    stages = []
    for stage in parent.stages:
        matches = [item for item in stage.schedule.get("instance_ids", []) if item in selected]
        if matches:
            stages.append(stage.model_copy(deep=True, update={"schedule": {**stage.schedule, "instance_ids": matches}}))
    if sum(len(stage.schedule["instance_ids"]) for stage in stages) != 1:
        raise RuntimeError("Selected smoke instance is not unique in the official parent schedule")
    schedule_id = plan["effective_config"]["task"]["params"]["schedule"]
    derived = parent.model_copy(deep=True, update={
        "id": schedule_id,
        "display_name": "RSI single-instance wiring check",
        "description": "Explicit one-instance subset of pinned official default; original task, variant and scorer.",
        "stages": stages,
        "run_defaults": schedules.TaskScheduleRunDefaults(runs=1, max_workers=1, mode="replicate"),
    })

    def catalog(family: str):
        official = original_catalog(family)
        return (*official, derived) if family == "codebase_adaptation" else official

    catalog.cache_clear = original_catalog.cache_clear
    schedules.list_task_schedules = catalog
    return {"parent_schedule": "default", "derived_schedule": derived.model_dump(), "original_dataset_modified": False}


def main() -> None:
    control = Path(sys.argv[1]).resolve()
    validate_only = "--validate-only" in sys.argv[2:]
    plan = json.loads(control.read_text(encoding="utf-8-sig"))
    source = Path(plan["linux_source"])
    archive = Path(plan["linux_archive"])
    native = Path(plan["linux_runtime"])
    if validate_only:
        archive = control.parent.parent
        native = native.with_name(native.name + "_validation")
    if native.exists():
        raise RuntimeError("Runtime directory already exists; never overwrite attempts")
    native.mkdir(parents=True)
    native.joinpath("data").symlink_to(source / "data", target_is_directory=True)
    sys.path.insert(0, str(source))
    if not validate_only and os.environ.get("OPENAI_BASE_URL") != plan["api_base_url"]:
        raise RuntimeError("Router URL missing or inconsistent")
    if not validate_only and not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError("API key not injected")

    derivation = install_smoke_schedule(plan)
    if derivation is not None:
        (archive / "control" / "schedule-derivation.json").write_text(json.dumps(derivation, indent=2), encoding="utf-8")

    from src.registry import register_system
    from src.systems.codex.system import CodexSystem

    if plan.get("actor_isolation") == "pr26_sanitized":
        from src.tasks.codebase_adaptation.task import CodebaseAdaptationTask
        initialize = CodebaseAdaptationTask._initialize_generic_pr_workspace

        def audited_actor_initialization(self, instance):
            def git(*arguments, check=True):
                return subprocess.run(["docker", "exec", "-w", "/testbed", self._env.container_id, "git", *arguments], check=check, text=True, capture_output=True, timeout=30)
            expected_tree = git("rev-parse", instance.raw_data["base_commit"] + "^{tree}").stdout.strip()
            initialize(self, instance)
            actual_tree = git("rev-parse", "HEAD^{tree}").stdout.strip()
            count = int(git("rev-list", "--all", "--count").stdout.strip())
            inaccessible = git("cat-file", "-e", instance.raw_data["base_commit"] + "^{commit}", check=False).returncode != 0
            record = {"instance_id": instance.instance_id, "container_id": self._env.container_id, "expected_base_tree": expected_tree, "actual_actor_tree": actual_tree, "base_tree_matches": actual_tree == expected_tree, "git_commit_count": count, "inherited_base_object_inaccessible": inaccessible, "actor_head": git("rev-parse", "HEAD").stdout.strip()}
            if not self.sanitize_actor_workspace or not record["base_tree_matches"] or count != 1 or not inaccessible:
                raise RuntimeError("Actor boundary verification failed before model execution")
            with (archive / "control/actor-boundaries.jsonl").open("a", encoding="utf-8") as output:
                output.write(json.dumps(record) + "\n")
        CodebaseAdaptationTask._initialize_generic_pr_workspace = audited_actor_initialization

    class RouterConfiguredCodex(CodexSystem):
        # Identical inherited constructor/signature, interaction and grading;
        # only provider configuration and explicitly selected baseline policy.
        supports_baseline = plan["include_baseline"]
        # The pinned upstream can create a spawn pool for a paired baseline
        # even with max_workers=1. Keep this locally configured class inline.
        parallel_safe = False

        def _docker_exec(self, command, *, timeout=None):
            if command.startswith("codex "):
                # Codex session files must be owned by the host runner so a
                # baseline reset can actually remove sessions and memories.
                return subprocess.run(["docker", "exec", "--user", f"{os.getuid()}:{os.getgid()}", "-e", "HOME=/workspace", "-w", "/workspace", self._container_id, "bash", "-lc", command], capture_output=True, text=True, timeout=timeout or self._timeout)
            return super()._docker_exec(command, timeout=timeout)

        def _start_container(self) -> None:
            super()._start_container()
            provider_config = (
                'model_provider = "rsi_router"\n'
                '[model_providers.rsi_router]\n'
                'name = "RSI AffordableRouter"\n'
                f'base_url = {json.dumps(plan["api_base_url"])}\n'
                'env_key = "OPENAI_API_KEY"\n'
                'wire_api = "responses"\n'
                'requires_openai_auth = false\n'
                'supports_websockets = false\n'
                'request_max_retries = 1\n'
            )
            encoded = base64.b64encode(provider_config.encode()).decode("ascii")
            result = self._docker_exec(
                "umask 077; printf '%s' " + encoded
                + " | base64 -d > /workspace/.codex/config.toml"
                + f" && chown {os.getuid()}:{os.getgid()} /workspace/.codex/config.toml /workspace/.codex/auth.json"
                + " && chmod 600 /workspace/.codex/config.toml /workspace/.codex/auth.json",
                timeout=15,
            )
            if result.returncode:
                raise RuntimeError("Could not install router config inside Codex container")

    register_system("codex")(RouterConfiguredCodex)
    config = plan["effective_config"]
    if plan["purpose"] == "smoke":
        from src.tasks.codebase_adaptation.task import CodebaseAdaptationTask
        probe = CodebaseAdaptationTask(**config["task"]["params"])
        if probe.num_instances != 1 or probe._schedule_instance_ids != plan["instance_ids"]:
            raise RuntimeError("Effective task does not select exactly the intended one instance")
        if probe.max_steps_per_issue != config["task"]["params"]["max_steps_per_issue"]:
            raise RuntimeError("Effective step budget differs from the planned budget")
    config_path = archive / "control" / "effective-clbench.json"
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    os.chdir(native)
    sys.argv = [
        "clbench", "run", "--config", str(config_path),
        "--runs", str(config["runs"]), "--max-workers", "1",
        "--run-mode", config["run_mode"],
        "--output", str(native / "summary.json"),
        "--run-group-id", plan["run_id"],
        "--live-dashboard" if plan.get("live_snapshots") else "--no-live-dashboard", "--no-live-server",
    ]
    if validate_only:
        sys.argv.append("--dry-run")
    metadata = {
        "extension": "router config injection into upstream native Codex adapter",
        "upstream_sha": plan["benchmark_sha"],
        "include_baseline": plan["include_baseline"],
        "cli_argv": sys.argv,
        "bridge_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "runtime": str(native),
        "validation_only": validate_only,
        "native_codex_uid": os.getuid(),
        "native_codex_gid": os.getgid(),
        "actor_isolation": plan.get("actor_isolation", "legacy_upstream"),
    }
    (archive / "control" / "adapter.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    signal.signal(signal.SIGINT, signal.default_int_handler)
    try:
        from src.cli import main as clbench_main
        clbench_main()
    finally:
        # Copy only native outputs. Do not copy the data symlink, venv, global
        # home, auth.json, or the Codex executor workspace containing credentials.
        target = archive / "native"
        target.mkdir(exist_ok=True)
        for item in native.iterdir():
            if item.name == "data" or item.is_symlink():
                continue
            dest = target / item.name
            if item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(item, dest)


if __name__ == "__main__":
    main()
