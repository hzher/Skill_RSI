from past_bench.graders.pg02 import PG02TaskGrader


class TaskGrader(PG02TaskGrader):
    pass
