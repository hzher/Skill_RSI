from past_bench.graders.pg03 import PG03TaskGrader


class TaskGrader(PG03TaskGrader):
    pass
