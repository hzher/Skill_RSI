from past_bench.graders.sm01 import SM01TaskGrader

class TaskGrader(SM01TaskGrader):
    pass
