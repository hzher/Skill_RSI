# SM01 core evidence revision

Protocol and native grading contract: `sm01-core-v4`. All original eight episode IDs,
fixtures, tool schemas, taught preference and history branches are retained. Only
"today's" is clarified to "the provided" in public requests; no mapping, year-solving
step, TSV reminder, owner, date answer or action instruction is added to eval inputs.

Cold does not require an untaught style. Style checks are column-specific. Content,
complete preference semantics and absence of persistent case facts receive separate
recorded semantic verdicts. Sharing requires actual successful calls and exact audit
recipients. Memory writes are replayed against their arguments and returned states.
Seed must start without memory and actually save the complete taught preference.
Reuse must receive the inherited memory in the actual prompt, with no public re-teaching.
Artifact checks cover all family cases and paraphrases, not only current exact tokens.

The original no-persistence control is fresh and has persistence disabled. Its original
style-compliance target remains; business correctness and style are separately reported.
It is not converted to a positive recovery or safe-abstention task. Coincidental style
success is not memory reuse. Family core acceptance additionally requires audited
seed-to-near/far lineage, clean public inputs, actual content/sharing correctness and
no durable task facts. A total pass count alone is not a core-ability verdict.

All applicable checks, safety and robustness must reach full score for a task pass.
These corrected scores are versioned separately from original and recovery variants.

All active framework-generated procedures are inspected even when runtime persistence is disabled. This evaluator-only evidence never reaches actor inputs.
