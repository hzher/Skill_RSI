# EP01_prior_case_recall — local authorized-history recovery revision

Protocol: `ep01-recovery-v4`. Grading contract: `ep01-upstream-v4`.
This local revision replaces the original no-persistence negative control with
an explicitly named positive history-recovery control. Scores are not comparable
to the original no-persistence experiment or historical 204-task reports.

Each task's native `grader.py` loads `past_bench.graders.ep01.EP01TaskGrader`;
no Skill_RSI sidecar is needed. `expectations.json` lists the applicable required
checks and `task.yaml` contains the host-only rubric. Full applicable checks,
semantic Judge, safety and robustness can reach score=1 through the ordinary
`grade_episode` and `is_pass` path. Missing evidence or guessed citations cannot
be compensated by keyword hits. The Judge receives complete actual tool returns.
Cold/noise checks are task-specific; faithful source date wording does not need
an invented year or extra disclaimer. Historical allowances do not automatically
establish present validity.

**Ability**: `memory_ability`
**Primary trigger**: `explicit_instruction`
**Expected substrate**: `session_search`
**Family length tier**: `tier2` (total 8 episodes)
**Transfer distance**: `near_far` · **Overwrite**: `not_required`

## Purpose
Prove that vague references to prior work can trigger correct session retrieval rather than re-derivation or over-storage.

## Must Demonstrate
- relevant prior session is retrieved on vague cue
- retrieval precedes the decisive action
- episodic content is not promoted into durable memory unnecessarily

## Bucket Plan
- `cold`: 1
- `learn`: 2
- `eval_near`: 1
- `eval_far`: 1
- `control`: 3

## Common Pitfalls to Avoid
- user restates episodic detail in eval
- over-storing one-off context as durable memory

## Status
Eight revised episodes are present. Eval fixtures do not expose the seed note
directly. Near, far, shortcut, wrong-mechanism and the new
`EP01_I06_control_history_recovery` independently load `ep01_post_learn`.
Only session_search is enabled; Executor memory and skills stay disabled.
Business state resets every episode. I06 is a renamed/reconfigured task, not a
claim that the original no-persistence task has been solved unchanged.

The family explicitly declares `evaluation_protocol: ep01-recovery-v4`.
The original authored-family no-persistence validation remains enforced for all
other protocols. Original source is available at commit
`f8223517ae7491e776b69793d9f11e9d074ab42e` and in the workspace's dated source backup.
Original run receipts remain intact. Private rubrics, expectations and grading
evidence must never be forwarded to Executor or Curator.
