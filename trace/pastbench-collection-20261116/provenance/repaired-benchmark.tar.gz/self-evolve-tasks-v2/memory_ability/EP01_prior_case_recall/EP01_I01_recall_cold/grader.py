from past_bench.graders.ep01 import EP01TaskGrader


class TaskGrader(EP01TaskGrader):
    pass
