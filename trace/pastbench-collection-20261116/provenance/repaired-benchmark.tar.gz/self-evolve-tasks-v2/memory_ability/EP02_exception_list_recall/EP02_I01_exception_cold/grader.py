from past_bench.graders.ep02 import EP02TaskGrader


class TaskGrader(EP02TaskGrader):
    pass
