"""Opt-in repair for declared positive score budgets that sum to less than one."""
import math

VERSION = 'positive-budget-v1'
DIRECT_WEIGHTS = ('memory_call_weight', 'skill_manage_weight', 'session_search_weight',
                  'memory_read_weight', 'memory_injection_weight', 'skill_read_weight',
                  'skill_update_weight', 'skill_write_weight', 'skill_artifact_weight',
                  'stale_override_weight', 'selective_memory_weight')


def internal_budget(expectations):
    weights = [float(expectations.get(name, 0.0)) for name in DIRECT_WEIGHTS]
    if expectations.get('require_memory_artifact'):
        weights.append(float(expectations.get('memory_artifact_weight', 0.0)))
    if expectations.get('require_rule_artifact'):
        weights.append(float(expectations.get('rule_artifact_weight', 0.0)))
    if any(not math.isfinite(w) or w < 0 for w in weights):
        raise ValueError('Invalid positive scoring weight')
    return math.fsum(weights)


def normalize(grader, expectations, earned, base_budget):
    contract = expectations.get('score_normalization')
    if contract is None:
        return earned
    if contract != VERSION:
        raise ValueError('Unknown positive score budget contract')
    budget = math.fsum((base_budget, internal_budget(expectations)))
    if not 0 < budget < 1.0 - 1e-12:
        raise ValueError('Normalization is limited to proven undersummed budgets')
    normalized = 1.0 if math.isclose(earned, budget, rel_tol=0.0, abs_tol=1e-12) else earned / budget
    grader.last_contract_result = {'schema': VERSION, 'positive_budget': budget,
                                  'raw_earned_before_caps': earned,
                                  'normalized_before_caps': normalized,
                                  'original_component_checks_penalties_and_caps_retained': True}
    return normalized
